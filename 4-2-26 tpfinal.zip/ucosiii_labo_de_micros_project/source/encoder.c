/*
 * encoder.c
 *
 *  Created on: Aug 30, 2025
 *      Author: julie
 */

#include "gpio.h"
#include "board.h"
#include "encoder.h"
#include "timer.h"

/* ============================================================================
 * Module internal variables
 * ==========================================================================*/


static bool state_A;
static bool state_B;
static bool current_state_A;
static bool current_state_B;
static int indicador_suma_resta = 0; //la G del paint lele
static tim_id_t id_encoder_1;
static enc_callback_t usuario_fun;
static bool boton_presionado;


#define ENCODER_ACTIVE LOW

/*Prototipo de funciones internas*/

void cambiar_estado_A ();
void timer_fun(void);

#define A_ENCODER_PIN gpioRead(A_ENCODER)
#define B_ENCODER_PIN gpioRead(B_ENCODER)

bool enconderInit (enc_callback_t fun){

	gpioMode (BOTON_ENCODER, INPUT);
	gpioMode (A_ENCODER, INPUT);
	gpioMode (B_ENCODER, INPUT);

	usuario_fun=fun;

	if (gpioRead(BOTON_ENCODER) == ENCODER_ACTIVE)
	{
		boton_presionado = true;
	}
	else{
		boton_presionado = false;
	}
	if ((A_ENCODER_PIN) == ENCODER_ACTIVE)
	{
		state_A = true;
	}
	else
	{
		state_A = false;
	}
	if (B_ENCODER_PIN == ENCODER_ACTIVE)
	{
		state_B = true;
	}
	else{
		state_B = false;
	}
	timerStart(0.5, TIM_MODE_PERIODIC_NO_CRITICAL , cambiar_estado_A);
	id_encoder_1=timerStart(10, TIM_MODE_PERIODIC_NO_CRITICAL, timer_fun);

	return boton_presionado;
}

//un 1 es sin tocar. un 0 es tocando

void cambiar_estado_A (){
	current_state_A = !A_ENCODER_PIN;
	current_state_B = !B_ENCODER_PIN;

	if(current_state_A != state_A){
		state_A = current_state_A;

		if((state_A == true) && (state_B == true)){ //ingresas desde el estado 11 y vas al 01
			indicador_suma_resta++;

		}
		else if((state_A == false) && (state_B == true)){ //ingresas desde el estado 01 y vas al 11
			indicador_suma_resta--;

		}
		else if((state_A == true) && (state_B == false)){ //ingresas desde el estado 10 y vas al estado 00
			indicador_suma_resta--;

		}
		else if((state_A == false) && (state_B == false)){ // ingresas desde el estado 00 y vas al 10
			indicador_suma_resta++;
		}
	}
	if(current_state_B != state_B)
	{
		state_B=current_state_B;
		if((state_A == true) && (state_B == true)){ //ingresas desde el estado 11 y vas al 10
				indicador_suma_resta--;
			}
			else if((state_A == true) && (state_B == false)){ //ingresas desde el estado 10 y vas al 11
				indicador_suma_resta++;
			}
			else if((state_A == false) && (state_B == true)){ //ingresas desde el estado 01 y vas al estado 00
				indicador_suma_resta++;
			}
			else if((state_A == false) && (state_B == false)){ // ingresas desde el estado 00 y vas al 01
				indicador_suma_resta--;
			}
	}


}

int update_encoder (void){
	if (indicador_suma_resta >= 4){
		indicador_suma_resta -= 4;
		return GIRO_DER;
	}
	else if (indicador_suma_resta <= -4){
		indicador_suma_resta += 4;
		return GIRO_IZQ;
	}
	else
		return 0;
}

void timer_fun(void){
	static int contador=0;
	if(contador>=1)
	{
		contador--;
	}
	if(contador==0)
	{
		bool boton = !gpioRead(BOTON_ENCODER); //gpioread lee un 0 si se apreta, pero quiero guardar un 1
		if(boton!=boton_presionado)
		{
			boton_presionado=boton;
			usuario_fun(boton_presionado);
			contador=5;
		}
	}
}
void encoderReset(void)
{
    indicador_suma_resta = 0;
}
