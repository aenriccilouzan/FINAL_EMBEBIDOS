/*
 * tarjeta_magnetica.c
 *
 *  Created on: 31 ago. 2025
 *      Author: andrea kpa
 */
#include "tarjeta_magnetica.h"
#include "gpio.h"
#include "board.h"


/* ============================================================================
 * Module internal variables
 * ==========================================================================*/

static uint8_t digito_actual = 0;             /**< Acumula los bits del carácter en curso */
static uint8_t contador_bits = 0;             /**< Cuenta los bits recibidos de un carácter */
static bool columna_acumulada[CANTIDAD_DATOS_TARJETA] = {0}; /**< Verificación de paridad por columna */
static bool lectura_completa=false;                 /**< Indica si se completó la lectura de una tarjeta */
struct dataLM datos_tarjeta;                  /**< Estructura global con los datos decodificados */
static bool trama_iniciada = false;           /**< Señal de inicio de trama */

/* Prototipos de funciones internas */
static void guardar_caracter(void);
void reset_datos_tarjeta(void);



void inicializar_tarjeta(void)
{
	gpioMode(ENABLE_TARJETA_MAGNETICA, INPUT);
	gpioMode(DATA_TARJETA, INPUT);
	gpioMode(CLOCK_TARJETA_MAGNETICA, INPUT);
	gpioIRQ(CLOCK_TARJETA_MAGNETICA, GPIO_IRQ_MODE_FALLING_EDGE, &guardar_dato_serie);
}

void guardar_dato_serie(void){ //contador empieza en 0, recibo el primer bit lo guardo en la primera posicion
	gpioWrite(PIN_LED_BLUE,LOW);
	static bool contador_de_unos=0; //HACER UNA XOR QUE COMPARA PARIDAD CONTADORUNOS XOR= BIT ACTUAL
	bool bit_actual;

	if (gpioRead(ENABLE_TARJETA_MAGNETICA)==LOW)
	{
		bit_actual= !(gpioRead(DATA_TARJETA));//estamos negando pq la entrada está negada
		if(bit_actual==HIGH && trama_iniciada==false)
		{
			trama_iniciada=true;
		}
		if(trama_iniciada==true)
		{
			if(contador_bits < CANTIDAD_DATOS_TARJETA)
			{
				columna_acumulada[contador_bits] ^= bit_actual; //te guarda si las columnas son pares o impares
				digito_actual |= (bit_actual << contador_bits);
				contador_de_unos^= bit_actual; //para saber si es par o impar
				contador_bits++;
			}
			else
			{
				if((contador_de_unos==IMPAR && bit_actual==PAR) ||(contador_de_unos==PAR && bit_actual==IMPAR))
				{
					guardar_caracter();
				}
				else
				{
					datos_tarjeta.error=true;
				}
				contador_bits=0;
				contador_de_unos=0;
				digito_actual=0;
			}
		}

	}
	else
	{

	}
	gpioWrite(PIN_LED_BLUE,HIGH);
}

void guardar_caracter(void)
{
	static uint8_t campo_actual=SS;
	static uint8_t indice_campo=0;
	char caracter_ascii = digito_actual+ '0';
//	if (lectura_completa==false)
//	{
		switch(campo_actual)
		{
		case SS:
			if(caracter_ascii== ';' )
			{
				//lectura_completa=true;
				campo_actual=PAN;
				indice_campo=0;
				reset_datos_tarjeta();
			}
			break;
		case PAN:
			//lectura_completa=true;
			if(caracter_ascii != '=' ) //preguntar si no es terminador
			{
				if(indice_campo<SIZE_PAN)
				{
					datos_tarjeta.PAN[indice_campo]= caracter_ascii; //mandamos ascii ya
					indice_campo++;
				}
				else
				{
					datos_tarjeta.error=true;
					indice_campo=0;
				}
			}
			else
			{
				//lectura_completa=true;
				campo_actual= AD;
				indice_campo=0;
			}
			break;

		case AD:

			if(indice_campo < SIZE_AD)
			{
				datos_tarjeta.AD[indice_campo]= caracter_ascii; //mandamos ascii ya
				indice_campo++;
			}
			else
			{
				indice_campo=1;
				datos_tarjeta.DD[0]=caracter_ascii;
				campo_actual=DD;
			}
			break;

		case DD:
			if(caracter_ascii != '?' ) //preguntar si no es terminador
			{
				if(indice_campo<SIZE_DD)
				{
					datos_tarjeta.DD[indice_campo]= caracter_ascii; //mandamos ascii ya
					indice_campo++;
				}
				else
				{
					datos_tarjeta.error=true;
					indice_campo=0;
				}
			}
			else
			{
				campo_actual= LRC;
				indice_campo=0;
			}
			break;
		case LRC:
			lectura_completa=true;
			trama_iniciada=false;
			contador_bits=0;
			digito_actual=0;
			indice_campo=0;
			for(int i=0; i<CANTIDAD_DATOS_TARJETA; i++)
			{
				if(columna_acumulada[i]==1)
					datos_tarjeta.error=true;
				columna_acumulada[i]=0;
			}
			campo_actual=SS;
		}
//	}

}
void reset_datos_tarjeta(void)
{
	for(int i = 0; i < SIZE_PAN; i++) datos_tarjeta.PAN[i] = 0;
	for(int i = 0; i < SIZE_AD; i++) datos_tarjeta.AD[i] = 0;
	for(int i = 0; i < SIZE_DD; i++) datos_tarjeta.DD[i] = 0;
	datos_tarjeta.error = false;
}

struct dataLM* recibiendo_data(void)
{
	if(lectura_completa==true)
	{
		lectura_completa=false;
		return &datos_tarjeta;
	}
	else
	{
		return NULL;
	}
}

// puede seguir escribiendo, preguntar si no es mas grande del tamaño, si si ERROR
// campo siguiente es cuando llega el igual


