source/tarjeta_magnetica.o source/tarjeta_magnetica.d: \
 ../source/tarjeta_magnetica.c ../source/tarjeta_magnetica.h \
 ../source/gpio.h ../source/board.h
../source/tarjeta_magnetica.h:
../source/gpio.h:
../source/board.h:
