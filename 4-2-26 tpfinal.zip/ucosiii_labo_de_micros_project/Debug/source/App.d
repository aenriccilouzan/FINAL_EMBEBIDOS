source/App.o source/App.d: ../source/App.c ../source/tarjeta_magnetica.h \
 ../source/board.h ../source/gpio.h ../source/timer.h ../source/SysTick.h \
 ../SDK/CMSIS/MK64F12.h ../SDK/CMSIS/core_cm4.h \
 ../SDK/CMSIS/cmsis_version.h ../SDK/CMSIS/cmsis_compiler.h \
 ../SDK/CMSIS/cmsis_gcc.h ../SDK/CMSIS/system_MK64F12.h \
 ../SDK/CMSIS/MK64F12_features.h ../source/encoder.h ../source/display.h \
 ../source/fsm.h
../source/tarjeta_magnetica.h:
../source/board.h:
../source/gpio.h:
../source/timer.h:
../source/SysTick.h:
../SDK/CMSIS/MK64F12.h:
../SDK/CMSIS/core_cm4.h:
../SDK/CMSIS/cmsis_version.h:
../SDK/CMSIS/cmsis_compiler.h:
../SDK/CMSIS/cmsis_gcc.h:
../SDK/CMSIS/system_MK64F12.h:
../SDK/CMSIS/MK64F12_features.h:
../source/encoder.h:
../source/display.h:
../source/fsm.h:
