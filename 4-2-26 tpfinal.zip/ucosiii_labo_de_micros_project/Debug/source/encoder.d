source/encoder.o source/encoder.d: ../source/encoder.c ../source/gpio.h \
 ../source/board.h ../source/encoder.h ../source/timer.h \
 ../source/SysTick.h
../source/gpio.h:
../source/board.h:
../source/encoder.h:
../source/timer.h:
../source/SysTick.h:
