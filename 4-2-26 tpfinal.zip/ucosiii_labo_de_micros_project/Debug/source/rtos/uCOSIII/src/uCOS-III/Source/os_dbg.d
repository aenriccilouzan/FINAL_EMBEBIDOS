source/rtos/uCOSIII/src/uCOS-III/Source/os_dbg.o \
 source/rtos/uCOSIII/src/uCOS-III/Source/os_dbg.d: \
 ../source/rtos/uCOSIII/src/uCOS-III/Source/os_dbg.c \
 ../source/rtos/uCOSIII/src/uCOS-III/Source/os.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\ucosiii_config/os_cfg.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-CPU/cpu_core.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-CPU\ARM-Cortex-M4\GNU/cpu.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-CPU/cpu_def.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\ucosiii_config/cpu_cfg.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-LIB/lib_def.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uCOS-III\Source/os_type.h \
 C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uCOS-III\Ports\ARM-Cortex-M4\Generic\GNU/os_cpu.h
../source/rtos/uCOSIII/src/uCOS-III/Source/os.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\ucosiii_config/os_cfg.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-CPU/cpu_core.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-CPU\ARM-Cortex-M4\GNU/cpu.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-CPU/cpu_def.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\ucosiii_config/cpu_cfg.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uC-LIB/lib_def.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uCOS-III\Source/os_type.h:
C:\Users\aenriccilouzan\Downloads\ucosiii_labo_de_micros_project\ucosiii_labo_de_micros_project\source\rtos\uCOSIII\src\uCOS-III\Ports\ARM-Cortex-M4\Generic\GNU/os_cpu.h:
